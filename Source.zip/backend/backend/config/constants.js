module.exports = {
    ROLES: {
      WORKER: 'worker',
      SUPERVISOR: 'supervisor',
      CHILDREN: 'children',
    },
    FACE_MATCH_THRESHOLD: 0.6, // Threshold for facial recognition
  };